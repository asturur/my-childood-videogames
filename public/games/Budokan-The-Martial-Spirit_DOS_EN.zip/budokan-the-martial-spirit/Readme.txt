

Budokan : The Martial Art Spirit
--------------------------------------
Brought to you by Ambersoft (1998)
--------------------------------------
 mmmm   mm    mm  mmmm    mmmmm  mmmmm
mm  mm  mmm  mmm  mm  mm  mm	 mm  mm
mm  mm  mm mm mm  mmmmm   mmmm   mmmmm
mmmmmm  mm    mm  mm  mm  mm     mm m 
mm  mm  mm    mm  mm  mm  mm     mm  m
mm  mm  mm    mm  mmmm    mmmmm  mm  mm
--------------------------------------
Thanx to : SK, Charli, VAD, ZB, Rob
	